
#Activity 1 of day 2 : 

name = input("Enter Your Name: ")

output = name.replace("Randolfh", "Mr.")

print(output)

