name = input("Enter Your Name:")
mathGrade = input("Enter Your Grade:")
scieGrade = input("Enter Your Science Grade:")
engGrade = input("Enter Your English Grade: ")

sum = float(mathGrade) + float(scieGrade) + int(engGrade)

average = sum / 3


print("Your average is" + " "+ str(average))

